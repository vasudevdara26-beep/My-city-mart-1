import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { fetchMyShop } from '../services/vendorService';
import ShopSetupForm from '../components/shopkeeper/ShopSetupForm';

const navClass = ({ isActive }) =>
  `rounded-full px-4 py-1.5 text-sm font-semibold transition ${
    isActive ? 'bg-emerald-600 text-white' : 'text-gray-600 hover:bg-gray-100'
  }`;

export default function ShopkeeperLayout() {
  const { user, profile, signOut } = useAuth();
  const [shop, setShop] = useState(undefined); // undefined = loading, null = no shop yet
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    fetchMyShop(user.id)
      .then((s) => !cancelled && setShop(s))
      .catch((err) => {
        if (cancelled) return;
        setError(err.message);
        setShop(null);
      });
    return () => {
      cancelled = true;
    };
  }, [user.id]);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="sticky top-0 z-30 border-b border-gray-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <Link to="/shopkeeper" className="text-lg font-extrabold tracking-tight text-emerald-600">
            City<span className="text-gray-900">Market</span>
            <span className="ml-2 rounded bg-gray-900 px-1.5 py-0.5 text-[10px] font-bold uppercase text-white">Seller</span>
          </Link>

          {shop && (
            <nav className="flex gap-1">
              <NavLink to="/shopkeeper" end className={navClass}>Dashboard</NavLink>
              <NavLink to="/shopkeeper/products" className={navClass}>Products</NavLink>
            </nav>
          )}

          <div className="ml-auto flex items-center gap-3 text-sm">
            {shop?.status === 'approved' && (
              <Link to={`/shop/${shop.id}`} className="text-emerald-700 hover:underline">View storefront</Link>
            )}
            <span className="hidden text-gray-500 sm:inline">{profile?.full_name}</span>
            <button onClick={signOut} className="rounded-lg border border-gray-200 px-3 py-1.5 font-medium text-gray-700 hover:bg-gray-50">
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        {error && <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

        {shop === undefined ? (
          <div className="animate-pulse space-y-4">
            <div className="h-40 rounded-2xl bg-gray-200" />
            <div className="h-24 rounded-2xl bg-gray-200" />
          </div>
        ) : shop === null ? (
          <ShopSetupForm ownerId={user.id} onCreated={setShop} />
        ) : (
          <Outlet context={{ shop, setShop }} />
        )}
      </main>
    </div>
  );
}
