import { useCallback, useEffect, useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { fetchPendingShopCount } from '../services/adminService';

const linkClass = ({ isActive }) =>
  `flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm font-semibold transition ${
    isActive ? 'bg-emerald-600 text-white' : 'text-gray-600 hover:bg-gray-100'
  }`;

export default function AdminLayout() {
  const { profile, signOut } = useAuth();
  const [pending, setPending] = useState(0);

  const refreshPending = useCallback(() => {
    fetchPendingShopCount().then(setPending).catch(() => {});
  }, []);

  useEffect(() => {
    refreshPending();
  }, [refreshPending]);

  const nav = [
    { to: '/admin', label: 'Overview', icon: '📊', end: true },
    { to: '/admin/shops', label: 'Shops', icon: '🏪', badge: pending },
    { to: '/admin/commission', label: 'Commission & Payouts', icon: '💰' },
    { to: '/admin/users', label: 'Users', icon: '👥' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="sticky top-0 z-30 border-b border-gray-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
          <span className="text-lg font-extrabold tracking-tight text-emerald-600">
            City<span className="text-gray-900">Market</span>
            <span className="ml-2 rounded bg-gray-900 px-1.5 py-0.5 text-[10px] font-bold uppercase text-white">Admin</span>
          </span>
          <div className="ml-auto flex items-center gap-3 text-sm">
            <span className="hidden text-gray-500 sm:inline">{profile?.full_name}</span>
            <button onClick={signOut} className="rounded-lg border border-gray-200 px-3 py-1.5 font-medium text-gray-700 hover:bg-gray-50">
              Sign out
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 md:flex-row md:gap-6">
        <nav className="flex shrink-0 gap-1 overflow-x-auto md:w-56 md:flex-col" aria-label="Admin navigation">
          {nav.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={linkClass}>
              <span aria-hidden>{item.icon}</span>
              {item.label}
              {item.badge > 0 && (
                <span className="ml-auto rounded-full bg-amber-500 px-2 py-0.5 text-[11px] font-bold text-white">{item.badge}</span>
              )}
            </NavLink>
          ))}
        </nav>

        <main className="min-w-0 flex-1">
          <Outlet context={{ refreshPending }} />
        </main>
      </div>
    </div>
  );
}
