import { Link } from 'react-router-dom';
import Header from '../../components/common/Header';
import { useCart } from '../../context/CartContext';
import { formatCurrency } from '../../utils/formatCurrency';

export default function Cart() {
  const { items, addItem, decrementItem, removeItem, subtotal } = useCart();

  // Orders belong to one shop each, so the cart is grouped by shop
  const groups = Object.values(
    items.reduce((acc, item) => {
      (acc[item.shopId] ||= { shopId: item.shopId, shopName: item.shopName, items: [] }).items.push(item);
      return acc;
    }, {})
  );

  const increase = (i) =>
    addItem(
      { id: i.productId, name: i.name, price: i.price, unit: i.unit, image_urls: i.image ? [i.image] : [], stock_quantity: i.stock },
      { id: i.shopId, name: i.shopName }
    );

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        <h1 className="text-2xl font-bold text-gray-900">Your cart</h1>

        {items.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center">
            <div className="text-4xl" aria-hidden>🛒</div>
            <p className="mt-2 font-semibold text-gray-800">Your cart is empty</p>
            <Link to="/" className="mt-3 inline-block rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white">
              Browse shops
            </Link>
          </div>
        ) : (
          <>
            {groups.map((g) => (
              <section key={g.shopId} className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
                <Link to={`/shop/${g.shopId}`} className="font-bold text-gray-900 hover:text-emerald-700">
                  🏪 {g.shopName}
                </Link>
                <ul className="mt-2 divide-y divide-gray-100">
                  {g.items.map((i) => (
                    <li key={i.productId} className="flex items-center gap-3 py-3">
                      <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-gray-100 text-xl text-gray-300">
                        {i.image ? <img src={i.image} alt={i.name} className="h-full w-full object-cover" /> : '🛍️'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-medium text-gray-900">{i.name}</p>
                        <p className="text-xs text-gray-500">{formatCurrency(i.price)} per {i.unit}</p>
                      </div>
                      <div className="flex items-center rounded-lg border border-gray-200 text-sm">
                        <button onClick={() => decrementItem(i.productId)} aria-label="Decrease" className="px-3 py-1.5 font-bold">−</button>
                        <span className="w-6 text-center">{i.quantity}</span>
                        <button onClick={() => increase(i)} disabled={i.quantity >= i.stock} aria-label="Increase" className="px-3 py-1.5 font-bold disabled:opacity-30">+</button>
                      </div>
                      <p className="w-20 text-right font-semibold text-gray-900">{formatCurrency(i.price * i.quantity)}</p>
                      <button onClick={() => removeItem(i.productId)} aria-label={`Remove ${i.name}`} className="text-gray-400 hover:text-red-500">✕</button>
                    </li>
                  ))}
                </ul>
              </section>
            ))}

            <div className="flex items-center justify-between rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
              <div>
                <p className="text-sm text-gray-500">Subtotal</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(subtotal)}</p>
              </div>
              <button disabled title="Checkout is the next build step" className="cursor-not-allowed rounded-lg bg-gray-200 px-5 py-2.5 font-semibold text-gray-500">
                Checkout (coming next)
              </button>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
