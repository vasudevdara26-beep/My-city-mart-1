import { useEffect, useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import ProductForm from '../../components/shopkeeper/ProductForm';
import {
  createProduct, deleteProduct, fetchShopProducts, updateProduct,
} from '../../services/vendorService';
import { getCategoryMeta } from '../../utils/constants';
import { formatCurrency } from '../../utils/formatCurrency';

export default function Products() {
  const { shop } = useOutletContext();

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    let cancelled = false;
    fetchShopProducts(shop.id)
      .then((data) => !cancelled && setProducts(data))
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [shop.id]);

  // Auto-hide success notice
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(''), 3000);
    return () => clearTimeout(t);
  }, [notice]);

  async function handleSave(values) {
    setSaving(true);
    setError('');
    try {
      if (editing) {
        const updated = await updateProduct(editing.id, values);
        setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
        setEditing(null);
        setNotice('Product updated');
      } else {
        const created = await createProduct(shop.id, values);
        setProducts((prev) => [created, ...prev]);
        setNotice('Product added');
      }
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(product) {
    if (!window.confirm(`Delete “${product.name}”? This can't be undone.`)) return;
    setBusyId(product.id);
    setError('');
    try {
      await deleteProduct(product.id);
      setProducts((prev) => prev.filter((p) => p.id !== product.id));
      if (editing?.id === product.id) setEditing(null);
      setNotice('Product deleted');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleToggleAvailable(product) {
    setBusyId(product.id);
    setError('');
    try {
      const updated = await updateProduct(product.id, { is_available: !product.is_available });
      setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function startEdit(product) {
    setEditing(product);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Products</h1>

      <ProductForm
        key={editing?.id ?? 'new'}
        initial={editing}
        onSubmit={handleSave}
        onCancel={() => setEditing(null)}
        submitting={saving}
      />

      {notice && <div className="rounded-xl bg-emerald-50 p-3 text-sm font-medium text-emerald-700">✓ {notice}</div>}
      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

      <section aria-label="Your products">
        <h2 className="mb-3 text-lg font-bold text-gray-900">
          Your products <span className="text-sm font-normal text-gray-500">({products.length})</span>
        </h2>

        {loading ? (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => <div key={i} className="h-20 animate-pulse rounded-2xl bg-gray-200" />)}
          </div>
        ) : products.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center text-gray-500">
            <div className="text-4xl" aria-hidden>🛍️</div>
            <p className="mt-2">No products yet. Add your first one above.</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {products.map((p) => {
              const cat = getCategoryMeta(p.category);
              const image = p.image_urls?.[0];
              const stockTone =
                p.stock_quantity === 0 ? 'text-red-600' : p.stock_quantity <= 5 ? 'text-amber-600' : 'text-gray-600';
              return (
                <li
                  key={p.id}
                  className={`flex flex-wrap items-center gap-4 rounded-2xl border bg-white p-3 shadow-sm ${
                    editing?.id === p.id ? 'border-emerald-400 ring-1 ring-emerald-400' : 'border-gray-100'
                  } ${p.is_available ? '' : 'opacity-70'}`}
                >
                  <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gray-100 text-2xl text-gray-300">
                    {image ? <img src={image} alt={p.name} className="h-full w-full object-cover" /> : '🛍️'}
                  </div>

                  <div className="min-w-0 flex-1 basis-48">
                    <p className="truncate font-semibold text-gray-900">{p.name}</p>
                    <p className="text-xs text-gray-500">{cat.icon} {cat.label} · per {p.unit}</p>
                    <p className="text-sm">
                      <span className="font-bold text-gray-900">{formatCurrency(p.price)}</span>
                      {p.mrp && Number(p.mrp) > Number(p.price) && (
                        <span className="ml-2 text-xs text-gray-400 line-through">{formatCurrency(p.mrp)}</span>
                      )}
                      <span className={`ml-3 text-xs font-medium ${stockTone}`}>
                        {p.stock_quantity === 0 ? 'Out of stock' : `${p.stock_quantity} in stock`}
                      </span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => handleToggleAvailable(p)}
                      disabled={busyId === p.id}
                      className={`rounded-full px-3 py-1 text-xs font-semibold disabled:opacity-60 ${
                        p.is_available ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-200 text-gray-600'
                      }`}
                    >
                      {p.is_available ? 'Listed' : 'Hidden'}
                    </button>
                    <button onClick={() => startEdit(p)} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50">
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(p)}
                      disabled={busyId === p.id}
                      className="rounded-lg border border-red-200 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50 disabled:opacity-60"
                    >
                      Delete
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
