import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { supabase } from '../../lib/supabaseClient';
import ShopProfileCard from '../../components/shopkeeper/ShopProfileCard';
import OrderCard from '../../components/shopkeeper/OrderCard';
import { fetchShopOrders, updateOrderStatus, updateShop } from '../../services/vendorService';
import { ORDER_FILTERS } from '../../utils/orderStatus';
import { formatCurrency } from '../../utils/formatCurrency';

function Stat({ label, value, tone = 'text-gray-900' }) {
  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-gray-500">{label}</p>
      <p className={`mt-1 text-2xl font-bold ${tone}`}>{value}</p>
    </div>
  );
}

export default function Dashboard() {
  const { shop, setShop } = useOutletContext();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [updatingId, setUpdatingId] = useState(null);
  const [toggling, setToggling] = useState(false);
  const refetchTimer = useRef(null);

  const load = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      try {
        setOrders(await fetchShopOrders(shop.id));
        setError('');
      } catch (err) {
        setError(err.message || 'Could not load orders');
      } finally {
        setLoading(false);
      }
    },
    [shop.id]
  );

  useEffect(() => {
    load();
  }, [load]);

  // Live updates: refetch (debounced) when an order or order item changes
  useEffect(() => {
    const refetch = () => {
      clearTimeout(refetchTimer.current);
      refetchTimer.current = setTimeout(() => load(true), 600);
    };

    const channel = supabase
      .channel(`shop-orders-${shop.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `shop_id=eq.${shop.id}` }, refetch)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'order_items' }, refetch)
      .subscribe();

    return () => {
      clearTimeout(refetchTimer.current);
      supabase.removeChannel(channel);
    };
  }, [shop.id, load]);

  async function handleToggleOpen() {
    setToggling(true);
    try {
      setShop(await updateShop(shop.id, { is_open: !shop.is_open }));
    } catch (err) {
      setError(err.message);
    } finally {
      setToggling(false);
    }
  }

  async function handleStatusChange(order, newStatus) {
    setUpdatingId(order.id);
    setError('');
    try {
      const updated = await updateOrderStatus(order, newStatus);
      setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, ...updated } : o)));
    } catch (err) {
      setError(err.message || 'Could not update the order');
    } finally {
      setUpdatingId(null);
    }
  }

  const stats = useMemo(() => {
    const count = (statuses) => orders.filter((o) => statuses.includes(o.status)).length;
    return {
      fresh: count(['placed']),
      active: count(['accepted', 'preparing', 'out_for_delivery']),
      delivered: count(['delivered']),
      revenue: orders.filter((o) => o.status === 'delivered').reduce((s, o) => s + Number(o.total_amount), 0),
    };
  }, [orders]);

  const activeFilter = ORDER_FILTERS.find((f) => f.id === filter);
  const visibleOrders = activeFilter.statuses
    ? orders.filter((o) => activeFilter.statuses.includes(o.status))
    : orders;

  return (
    <div className="space-y-6">
      <ShopProfileCard shop={shop} onToggleOpen={handleToggleOpen} toggling={toggling} />

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4" aria-label="Order summary">
        <Stat label="New orders" value={stats.fresh} tone={stats.fresh > 0 ? 'text-amber-600' : undefined} />
        <Stat label="In progress" value={stats.active} />
        <Stat label="Delivered" value={stats.delivered} />
        <Stat label="Delivered revenue" value={formatCurrency(stats.revenue)} tone="text-emerald-700" />
      </section>

      <section aria-label="Orders">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-bold text-gray-900">Incoming orders</h2>
          <button onClick={() => load()} className="text-sm font-medium text-emerald-700 hover:underline">↻ Refresh</button>
        </div>

        <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
          {ORDER_FILTERS.map((f) => {
            const n = f.statuses ? orders.filter((o) => f.statuses.includes(o.status)).length : orders.length;
            return (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition ${
                  filter === f.id ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 ring-1 ring-gray-200 hover:bg-gray-50'
                }`}
              >
                {f.label} <span className="opacity-70">({n})</span>
              </button>
            );
          })}
        </div>

        {error && <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

        {loading ? (
          <div className="grid gap-4 lg:grid-cols-2">
            {[0, 1].map((i) => <div key={i} className="h-64 animate-pulse rounded-2xl bg-gray-200" />)}
          </div>
        ) : visibleOrders.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center">
            <div className="text-4xl" aria-hidden>📦</div>
            <p className="mt-2 font-semibold text-gray-800">No orders here yet</p>
            <p className="text-sm text-gray-500">New orders appear automatically.</p>
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {visibleOrders.map((order) => (
              <OrderCard key={order.id} order={order} updating={updatingId === order.id} onStatusChange={handleStatusChange} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
