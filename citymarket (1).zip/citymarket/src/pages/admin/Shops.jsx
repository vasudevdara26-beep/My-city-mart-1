import { useEffect, useMemo, useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import ShopReviewCard from '../../components/admin/ShopReviewCard';
import RejectDialog from '../../components/admin/RejectDialog';
import { fetchAllShops, setShopStatus } from '../../services/adminService';

const TABS = [
  { id: 'pending', label: 'Pending' },
  { id: 'approved', label: 'Approved' },
  { id: 'rejected', label: 'Rejected' },
  { id: 'suspended', label: 'Suspended' },
  { id: 'all', label: 'All' },
];

export default function Shops() {
  const { refreshPending } = useOutletContext();
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('pending');
  const [busyId, setBusyId] = useState(null);
  const [dialog, setDialog] = useState(null); // { shop, status: 'rejected' | 'suspended' }

  useEffect(() => {
    let cancelled = false;
    fetchAllShops()
      .then((data) => !cancelled && setShops(data))
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, []);

  const counts = useMemo(() => {
    const c = { all: shops.length };
    shops.forEach((s) => (c[s.status] = (c[s.status] || 0) + 1));
    return c;
  }, [shops]);

  const visible = tab === 'all' ? shops : shops.filter((s) => s.status === tab);

  async function changeStatus(shop, status, reason = null) {
    setBusyId(shop.id);
    setError('');
    try {
      const updated = await setShopStatus(shop.id, status, reason);
      setShops((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
      refreshPending();
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setBusyId(null);
    }
  }

  async function confirmDialog(reason) {
    const ok = await changeStatus(dialog.shop, dialog.status, reason);
    if (ok) setDialog(null);
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Shop verification</h1>
        <p className="text-sm text-gray-500">Review newly registered shops before they go live to customers.</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition ${
              tab === t.id ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 ring-1 ring-gray-200 hover:bg-gray-50'
            }`}>
            {t.label} <span className="opacity-70">({counts[t.id] || 0})</span>
          </button>
        ))}
      </div>

      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

      {loading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-36 animate-pulse rounded-2xl bg-gray-200" />)}</div>
      ) : visible.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center">
          <div className="text-4xl" aria-hidden>{tab === 'pending' ? '🎉' : '🏪'}</div>
          <p className="mt-2 font-semibold text-gray-800">{tab === 'pending' ? 'All caught up' : 'Nothing here'}</p>
          <p className="text-sm text-gray-500">{tab === 'pending' ? 'No shops are waiting for approval.' : 'No shops with this status.'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {visible.map((shop) => (
            <ShopReviewCard
              key={shop.id}
              shop={shop}
              busy={busyId === shop.id}
              onApprove={() => changeStatus(shop, 'approved')}
              onReject={() => setDialog({ shop, status: 'rejected' })}
              onSuspend={() => setDialog({ shop, status: 'suspended' })}
            />
          ))}
        </div>
      )}

      {dialog && (
        <RejectDialog
          shop={dialog.shop}
          verb={dialog.status === 'rejected' ? 'Reject' : 'Suspend'}
          onConfirm={confirmDialog}
          onClose={() => setDialog(null)}
        />
      )}
    </div>
  );
}
