import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import StatCard from '../../components/admin/StatCard';
import SalesChart from '../../components/admin/SalesChart';
import { fetchDailySales, fetchDashboardStats } from '../../services/adminService';
import { formatCurrency } from '../../utils/formatCurrency';

const PERIODS = [
  { id: 'today', label: 'Today', chartDays: 7 },
  { id: '7d', label: '7 days', chartDays: 7 },
  { id: '30d', label: '30 days', chartDays: 30 },
  { id: 'all', label: 'All time', chartDays: 30 },
];

function periodStart(id) {
  if (id === 'all') return null;
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  if (id === '7d') d.setDate(d.getDate() - 6);
  if (id === '30d') d.setDate(d.getDate() - 29);
  return d.toISOString();
}

const num = (n) => Number(n ?? 0).toLocaleString('en-IN');

export default function Overview() {
  const [period, setPeriod] = useState('30d');
  const [stats, setStats] = useState(null);
  const [daily, setDaily] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');
    const chartDays = PERIODS.find((p) => p.id === period).chartDays;

    Promise.all([fetchDashboardStats(periodStart(period)), fetchDailySales(chartDays)])
      .then(([s, d]) => {
        if (cancelled) return;
        setStats(s);
        setDaily(d);
      })
      .catch((err) => !cancelled && setError(err.message || 'Could not load the dashboard'))
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true;
    };
  }, [period]);

  const sales = Number(stats?.total_sales ?? 0);
  const commission = Number(stats?.total_commission ?? 0);
  const effectiveRate = sales > 0 ? `${((commission / sales) * 100).toFixed(1)}%` : '—';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-gray-900">Overview</h1>
        <div className="flex gap-1 rounded-full bg-white p-1 ring-1 ring-gray-200">
          {PERIODS.map((p) => (
            <button key={p.id} onClick={() => setPeriod(p.id)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${period === p.id ? 'bg-gray-900 text-white' : 'text-gray-600 hover:bg-gray-100'}`}>
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
          <p className="mt-1 text-red-600">If this mentions a missing function, run <code>admin_panel_migration.sql</code> in Supabase.</p>
        </div>
      )}

      {stats?.pending_shops > 0 && (
        <Link to="/admin/shops" className="flex items-center justify-between rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-medium text-amber-800 hover:bg-amber-100">
          <span>⏳ {stats.pending_shops} shop{stats.pending_shops > 1 && 's'} waiting for approval</span>
          <span>Review →</span>
        </Link>
      )}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Key metrics">
        <StatCard loading={loading} icon="🛒" label="Total sales" value={formatCurrency(sales)}
          hint={`${num(stats?.delivered_orders)} delivered orders`} />
        <StatCard loading={loading} icon="🏪" label="Active shops" value={num(stats?.active_shops)}
          hint={`${num(stats?.pending_shops)} awaiting approval`} />
        <StatCard loading={loading} icon="👥" label="Registered customers" value={num(stats?.total_customers)}
          hint={`${num(stats?.total_shopkeepers)} shopkeepers · all time`} />
        <StatCard loading={loading} icon="💰" label="Commission earned" value={formatCurrency(commission)} tone="text-emerald-700"
          hint={`${effectiveRate} of sales`} />
      </section>

      <section className="grid gap-4 sm:grid-cols-3" aria-label="More metrics">
        <StatCard loading={loading} icon="🏦" label="Shop earnings" value={formatCurrency(stats?.shop_earnings)} hint="Sales minus commission" />
        <StatCard loading={loading} icon="📦" label="Open orders now" value={num(stats?.open_orders)} hint="Placed, accepted, packing or on the way" />
        <Link to="/admin/commission" className="flex flex-col justify-center rounded-2xl border border-dashed border-emerald-300 bg-emerald-50 p-5 text-emerald-800 hover:bg-emerald-100">
          <span className="font-semibold">Manage commission & payouts →</span>
          <span className="text-xs text-emerald-700">See what each shop is owed</span>
        </Link>
      </section>

      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm" aria-label="Daily sales">
        <h2 className="mb-4 text-lg font-bold text-gray-900">Daily sales <span className="text-sm font-normal text-gray-500">(last {daily.length} days)</span></h2>
        {loading || daily.length === 0 ? <div className="h-52 animate-pulse rounded-xl bg-gray-100" /> : <SalesChart data={daily} />}
      </section>
    </div>
  );
}
