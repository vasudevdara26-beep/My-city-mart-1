import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { fetchUsers, updateUser } from '../../services/adminService';

const ROLES = ['customer', 'shopkeeper', 'admin'];
const ROLE_STYLE = {
  customer: 'bg-gray-100 text-gray-700',
  shopkeeper: 'bg-sky-100 text-sky-800',
  admin: 'bg-violet-100 text-violet-800',
};

export default function Users() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [role, setRole] = useState('');
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetchUsers({ role, search: debounced })
      .then((data) => !cancelled && (setUsers(data), setError('')))
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [role, debounced]);

  async function patchUser(u, patch) {
    setBusyId(u.id);
    setError('');
    try {
      const updated = await updateUser(u.id, patch);
      setUsers((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  function changeRole(u, next) {
    if (next === u.role) return;
    if (next === 'admin' && !window.confirm(`Give ${u.full_name} full admin access?`)) return;
    patchUser(u, { role: next });
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Users</h1>
        <p className="text-sm text-gray-500">
          Verify sellers by promoting them to <b>shopkeeper</b>. They can then register a shop for approval.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <input
          type="search" value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name or phone"
          className="min-w-[220px] flex-1 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm outline-none focus:border-emerald-500"
        />
        <select value={role} onChange={(e) => setRole(e.target.value)}
          className="rounded-full border border-gray-200 bg-white px-4 py-2 text-sm outline-none focus:border-emerald-500">
          <option value="">All roles</option>
          {ROLES.map((r) => <option key={r} value={r} className="capitalize">{r}</option>)}
        </select>
      </div>

      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

      <div className="overflow-x-auto rounded-2xl border border-gray-100 bg-white shadow-sm">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
            <tr>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Joined</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-gray-400">Loading…</td></tr>
            ) : users.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-gray-400">No users found.</td></tr>
            ) : (
              users.map((u) => {
                const isMe = u.id === me.id;
                return (
                  <tr key={u.id}>
                    <td className="px-4 py-3">
                      <p className="font-semibold text-gray-900">{u.full_name}{isMe && <span className="ml-2 text-xs font-normal text-gray-400">(you)</span>}</p>
                      <p className="text-xs text-gray-500">{u.phone || 'No phone'}</p>
                    </td>
                    <td className="px-4 py-3">
                      <select
                        value={u.role} disabled={isMe || busyId === u.id}
                        onChange={(e) => changeRole(u, e.target.value)}
                        aria-label={`Role for ${u.full_name}`}
                        className={`rounded-full px-3 py-1 text-xs font-semibold capitalize outline-none disabled:opacity-60 ${ROLE_STYLE[u.role]}`}
                      >
                        {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
                      </select>
                    </td>
                    <td className="px-4 py-3 text-gray-500">{new Date(u.created_at).toLocaleDateString('en-IN', { dateStyle: 'medium' })}</td>
                    <td className="px-4 py-3">
                      <button
                        disabled={isMe || busyId === u.id}
                        onClick={() => patchUser(u, { is_active: !u.is_active })}
                        className={`rounded-full px-3 py-1 text-xs font-semibold disabled:opacity-60 ${u.is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}
                      >
                        {u.is_active ? 'Active' : 'Blocked'}
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
