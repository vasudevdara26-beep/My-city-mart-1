import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import CommissionSettings from '../../components/admin/CommissionSettings';
import PayoutDialog from '../../components/admin/PayoutDialog';
import StatCard from '../../components/admin/StatCard';
import {
  fetchCommissionSettings, fetchPayouts, fetchShopBalances, recordPayout, updateShopCommission,
} from '../../services/adminService';
import { formatCurrency } from '../../utils/formatCurrency';

/* Inline per-shop rate override. Empty = use the platform default. */
function RateCell({ row, defaultRate, onSaved, onError }) {
  const initial = row.custom_rate == null ? '' : String(row.custom_rate);
  const [value, setValue] = useState(initial);
  const [busy, setBusy] = useState(false);

  async function commit() {
    if (value === initial) return;
    const rate = value === '' ? null : parseFloat(value);
    if (rate !== null && (Number.isNaN(rate) || rate < 0 || rate > 100)) {
      setValue(initial);
      return onError('Commission must be between 0 and 100.');
    }
    setBusy(true);
    try {
      await updateShopCommission(row.shop_id, rate);
      onSaved();
    } catch (err) {
      setValue(initial);
      onError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex items-center gap-1">
      <input
        type="number" min="0" max="100" step="0.5" value={value} disabled={busy}
        placeholder={String(defaultRate)}
        onChange={(e) => setValue(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
        aria-label={`Commission rate for ${row.shop_name}`}
        className="w-16 rounded-md border border-gray-300 px-2 py-1 text-sm outline-none focus:border-emerald-500 disabled:opacity-60"
      />
      <span className="text-xs text-gray-500">%{row.custom_rate == null && ' (default)'}</span>
    </div>
  );
}

function BalanceBadge({ balance }) {
  const b = Number(balance);
  if (Math.abs(b) < 0.01) return <span className="rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-500">Settled</span>;
  return b > 0 ? (
    <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-semibold text-emerald-800">Pay shop {formatCurrency(b)}</span>
  ) : (
    <span className="rounded-full bg-rose-100 px-2.5 py-1 text-xs font-semibold text-rose-700">Shop owes {formatCurrency(-b)}</span>
  );
}

export default function Commission() {
  const { user } = useAuth();
  const [settings, setSettings] = useState(null);
  const [rows, setRows] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [payoutRow, setPayoutRow] = useState(null);

  const load = useCallback(async () => {
    try {
      const [s, b, p] = await Promise.all([fetchCommissionSettings(), fetchShopBalances(), fetchPayouts()]);
      setSettings(s);
      setRows(b);
      setPayouts(p);
      setError('');
    } catch (err) {
      setError(err.message || 'Could not load commission data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const totals = useMemo(() => {
    const sum = (fn) => rows.reduce((acc, r) => acc + fn(r), 0);
    return {
      gross: sum((r) => Number(r.gross_sales)),
      commission: sum((r) => Number(r.commission_total)),
      payable: sum((r) => Math.max(Number(r.balance), 0)),
      receivable: sum((r) => Math.max(-Number(r.balance), 0)),
    };
  }, [rows]);

  async function handlePayout(values) {
    await recordPayout({ ...values, created_by: user.id });
    setPayoutRow(null);
    await load();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Commission & payouts</h1>
        <p className="text-sm text-gray-500">What the platform keeps, and what each shop is owed.</p>
      </div>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
          <p className="mt-1">If this mentions a missing table or function, run <code>admin_panel_migration.sql</code>.</p>
        </div>
      )}

      {settings && <CommissionSettings settings={settings} onSaved={setSettings} />}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Totals">
        <StatCard loading={loading} icon="🛒" label="Gross sales (delivered)" value={formatCurrency(totals.gross)} />
        <StatCard loading={loading} icon="💰" label="Stays with you (commission)" value={formatCurrency(totals.commission)} tone="text-emerald-700" />
        <StatCard loading={loading} icon="📤" label="To pay shopkeepers" value={formatCurrency(totals.payable)} tone="text-amber-600" hint="Outstanding balances" />
        <StatCard loading={loading} icon="📥" label="To collect from shops" value={formatCurrency(totals.receivable)} tone="text-rose-600" hint="Commission on cash orders" />
      </section>

      <section className="rounded-2xl border border-gray-100 bg-white shadow-sm" aria-label="Shop settlements">
        <div className="border-b border-gray-100 p-5">
          <h2 className="text-lg font-bold text-gray-900">Shop settlements</h2>
          <p className="mt-1 text-xs text-gray-500">
            Balance = shop earnings on online orders − commission owed on cash (COD) orders − settlements already recorded.
            Positive: you owe the shop. Negative: the shop owes you. Leave a rate blank to use the default.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[920px] text-left text-sm">
            <thead className="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-4 py-3">Shop</th>
                <th className="px-4 py-3">Rate</th>
                <th className="px-4 py-3 text-right">Orders</th>
                <th className="px-4 py-3 text-right">Gross sales</th>
                <th className="px-4 py-3 text-right">Admin keeps</th>
                <th className="px-4 py-3 text-right">Shop earns</th>
                <th className="px-4 py-3 text-right">Settled</th>
                <th className="px-4 py-3">Balance</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr><td colSpan={9} className="px-4 py-10 text-center text-gray-400">Loading…</td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={9} className="px-4 py-10 text-center text-gray-400">No shops or delivered orders yet.</td></tr>
              ) : (
                rows.map((r) => {
                  const net = Number(r.settled_to_shop) - Number(r.settled_from_shop);
                  const open = Math.abs(Number(r.balance)) >= 0.01;
                  return (
                    <tr key={r.shop_id} className="hover:bg-gray-50/60">
                      <td className="px-4 py-3">
                        <p className="font-semibold text-gray-900">{r.shop_name}</p>
                        <p className="text-xs text-gray-500">{r.owner_name || '—'}{r.shop_status !== 'approved' && ` · ${r.shop_status}`}</p>
                      </td>
                      <td className="px-4 py-3">
                        <RateCell row={r} defaultRate={settings?.default_commission_rate ?? 10} onSaved={load} onError={setError} />
                      </td>
                      <td className="px-4 py-3 text-right">{r.delivered_orders}</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(r.gross_sales)}</td>
                      <td className="px-4 py-3 text-right font-medium text-emerald-700">{formatCurrency(r.commission_total)}</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(r.shop_earnings)}</td>
                      <td className="px-4 py-3 text-right text-gray-500">{net === 0 ? '—' : formatCurrency(net)}</td>
                      <td className="px-4 py-3"><BalanceBadge balance={r.balance} /></td>
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => setPayoutRow(r)}
                          className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${open ? 'bg-gray-900 text-white hover:bg-gray-700' : 'border border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                          {open ? (Number(r.balance) > 0 ? 'Record payout' : 'Record receipt') : 'Record'}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm" aria-label="Settlement history">
        <h2 className="mb-3 text-lg font-bold text-gray-900">Settlement history</h2>
        {payouts.length === 0 ? (
          <p className="text-sm text-gray-400">No settlements recorded yet.</p>
        ) : (
          <ul className="divide-y divide-gray-100">
            {payouts.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
                <div>
                  <p className="font-medium text-gray-900">
                    {p.direction === 'to_shop' ? 'Paid to' : 'Received from'} {p.shop?.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(p.created_at).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                    {p.method && ` · ${p.method}`}{p.reference && ` · Ref ${p.reference}`}{p.note && ` · ${p.note}`}
                  </p>
                </div>
                <span className={`font-bold ${p.direction === 'to_shop' ? 'text-amber-600' : 'text-emerald-700'}`}>
                  {p.direction === 'to_shop' ? '−' : '+'}{formatCurrency(p.amount)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {payoutRow && <PayoutDialog row={payoutRow} onSubmit={handlePayout} onClose={() => setPayoutRow(null)} />}
    </div>
  );
}
