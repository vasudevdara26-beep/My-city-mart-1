import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import ShopkeeperRoute from './routes/ShopkeeperRoute';
import AdminRoute from './routes/AdminRoute';
import ShopkeeperLayout from './layouts/ShopkeeperLayout';
import AdminLayout from './layouts/AdminLayout';

import Home from './pages/customer/Home';
import ShopDetail from './pages/customer/ShopDetail';
import Cart from './pages/customer/Cart';
import Login from './pages/auth/Login';
import Dashboard from './pages/shopkeeper/Dashboard';
import Products from './pages/shopkeeper/Products';
import Overview from './pages/admin/Overview';
import Shops from './pages/admin/Shops';
import Commission from './pages/admin/Commission';
import Users from './pages/admin/Users';

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          <Routes>
            {/* Customer */}
            <Route path="/" element={<Home />} />
            <Route path="/shop/:shopId" element={<ShopDetail />} />
            <Route path="/cart" element={<Cart />} />

            {/* Auth */}
            <Route path="/login" element={<Login />} />

            {/* Shopkeeper */}
            <Route path="/shopkeeper" element={<ShopkeeperRoute><ShopkeeperLayout /></ShopkeeperRoute>}>
              <Route index element={<Dashboard />} />
              <Route path="products" element={<Products />} />
            </Route>

            {/* Admin */}
            <Route path="/admin" element={<AdminRoute><AdminLayout /></AdminRoute>}>
              <Route index element={<Overview />} />
              <Route path="shops" element={<Shops />} />
              <Route path="commission" element={<Commission />} />
              <Route path="users" element={<Users />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </CartProvider>
    </AuthProvider>
  );
}
