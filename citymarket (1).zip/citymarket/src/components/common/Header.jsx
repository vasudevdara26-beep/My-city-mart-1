import { Link } from 'react-router-dom';
import { CITIES } from '../../utils/constants';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

/**
 * City selector shows only when `onCityChange` is passed.
 * Search bar shows only when `onSearchChange` is passed.
 */
export default function Header({ city, onCityChange, search = '', onSearchChange }) {
  const { totalItems } = useCart();
  const { user, profile, signOut } = useAuth();

  const panel =
    profile?.role === 'admin'
      ? { to: '/admin', label: 'Admin' }
      : profile?.role === 'shopkeeper'
      ? { to: '/shopkeeper', label: 'My shop' }
      : null;

  return (
    <header className="sticky top-0 z-30 border-b border-gray-100 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
        <Link to="/" className="text-xl font-extrabold tracking-tight text-emerald-600">
          City<span className="text-gray-900">Market</span>
        </Link>

        {onCityChange && (
          <label className="flex items-center gap-1 rounded-full border border-gray-200 bg-gray-50 px-3 py-1.5 text-sm">
            <span aria-hidden>📍</span>
            <span className="sr-only">Select city</span>
            <select
              value={city}
              onChange={(e) => onCityChange(e.target.value)}
              className="bg-transparent font-medium text-gray-800 outline-none"
            >
              {CITIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
        )}

        {onSearchChange && (
          <div className="order-last w-full md:order-none md:flex-1">
            <div className="flex items-center gap-2 rounded-full border border-gray-200 bg-gray-50 px-4 py-2 focus-within:border-emerald-500 focus-within:bg-white">
              <span aria-hidden>🔍</span>
              <input
                type="search"
                value={search}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search shops near you"
                className="w-full bg-transparent text-sm outline-none placeholder:text-gray-400"
              />
            </div>
          </div>
        )}

        <div className="ml-auto flex items-center gap-1 text-sm">
          {panel && (
            <Link to={panel.to} className="rounded-full px-3 py-1.5 font-semibold text-emerald-700 hover:bg-emerald-50">
              {panel.label}
            </Link>
          )}
          {user ? (
            <button onClick={signOut} className="rounded-full px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100">
              Sign out
            </button>
          ) : (
            <Link to="/login" className="rounded-full px-3 py-1.5 font-medium text-gray-700 hover:bg-gray-100">
              Sign in
            </Link>
          )}
          <Link
            to="/cart"
            className="relative rounded-full p-2 text-xl hover:bg-gray-100"
            aria-label={`Cart with ${totalItems} items`}
          >
            🛒
            {totalItems > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-emerald-600 px-1 text-[11px] font-bold text-white">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
