import { getCategoryMeta } from '../../utils/constants';
import { formatCurrency } from '../../utils/formatCurrency';

const STATUS_BANNERS = {
  pending: { cls: 'bg-amber-50 text-amber-800 border-amber-200', text: '⏳ Awaiting admin approval. Customers can’t see your shop yet.' },
  suspended: { cls: 'bg-red-50 text-red-700 border-red-200', text: '⛔ Your shop is suspended. Contact support.' },
  rejected: { cls: 'bg-red-50 text-red-700 border-red-200', text: '❌ Your shop application was rejected.' },
};

export default function ShopProfileCard({ shop, onToggleOpen, toggling }) {
  const category = getCategoryMeta(shop.category);
  const image = shop.banner_url || shop.logo_url;
  const banner = STATUS_BANNERS[shop.status];

  return (
    <section className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
      {banner && <div className={`border-b px-5 py-2 text-sm font-medium ${banner.cls}`}>{banner.text}</div>}

      <div className="flex flex-col gap-4 p-5 sm:flex-row">
        <div className="flex h-24 w-full shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-emerald-100 to-teal-50 text-4xl sm:w-40">
          {image ? <img src={image} alt={shop.name} className="h-full w-full object-cover" /> : <span aria-hidden>{category.icon}</span>}
        </div>

        <div className="min-w-0 flex-1 space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="truncate text-xl font-bold text-gray-900">{shop.name}</h1>
            <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-700">{category.icon} {category.label}</span>
            {shop.status === 'approved' && <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-700">Approved</span>}
          </div>
          <p className="text-sm text-gray-600">📍 {shop.address}, {shop.city} {shop.pincode}</p>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
            {shop.phone && <span>📞 {shop.phone}</span>}
            {shop.opening_time && shop.closing_time && <span>🕒 {shop.opening_time.slice(0, 5)} – {shop.closing_time.slice(0, 5)}</span>}
            <span>🚚 {Number(shop.delivery_fee) > 0 ? formatCurrency(shop.delivery_fee) : 'Free delivery'}</span>
            {Number(shop.min_order_amount) > 0 && <span>Min order {formatCurrency(shop.min_order_amount)}</span>}
          </div>
        </div>

        <div className="flex items-center sm:flex-col sm:items-end sm:justify-center">
          <button
            onClick={onToggleOpen}
            disabled={toggling}
            aria-pressed={shop.is_open}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition disabled:opacity-60 ${
              shop.is_open ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {shop.is_open ? '● Shop is open' : '○ Shop is closed'}
          </button>
        </div>
      </div>
    </section>
  );
}
