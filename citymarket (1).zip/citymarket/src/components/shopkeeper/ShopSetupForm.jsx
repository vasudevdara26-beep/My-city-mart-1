import { useState } from 'react';
import { CATEGORIES, CITIES } from '../../utils/constants';
import { createShop } from '../../services/vendorService';

const input =
  'w-full rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500';

export default function ShopSetupForm({ ownerId, onCreated }) {
  const [form, setForm] = useState({
    name: '', category: CATEGORIES[0].id, city: CITIES[0], address: '',
    pincode: '', phone: '', description: '', latitude: '', longitude: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  function useMyLocation() {
    if (!navigator.geolocation) return setError('Geolocation is not supported by this browser.');
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        setForm((f) => ({
          ...f,
          latitude: pos.coords.latitude.toFixed(6),
          longitude: pos.coords.longitude.toFixed(6),
        })),
      () => setError('Could not get your location. Enter the coordinates manually.')
    );
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    const lat = parseFloat(form.latitude);
    const lng = parseFloat(form.longitude);
    if (Number.isNaN(lat) || Number.isNaN(lng)) return setError('Shop location (latitude & longitude) is required.');

    setBusy(true);
    try {
      const shop = await createShop(ownerId, {
        name: form.name.trim(),
        category: form.category,
        city: form.city,
        address: form.address.trim(),
        pincode: form.pincode.trim(),
        phone: form.phone.trim() || null,
        description: form.description.trim() || null,
        latitude: lat,
        longitude: lng,
      });
      onCreated(shop);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-2xl space-y-4 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
      <div>
        <h1 className="text-xl font-bold text-gray-900">Register your shop</h1>
        <p className="text-sm text-gray-500">An admin will review it before it goes live to customers.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="sm:col-span-2 text-sm font-medium text-gray-700">Shop name
          <input className={`${input} mt-1`} value={form.name} onChange={set('name')} required />
        </label>
        <label className="text-sm font-medium text-gray-700">Category
          <select className={`${input} mt-1`} value={form.category} onChange={set('category')}>
            {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
          </select>
        </label>
        <label className="text-sm font-medium text-gray-700">City
          <select className={`${input} mt-1`} value={form.city} onChange={set('city')}>
            {CITIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        <label className="sm:col-span-2 text-sm font-medium text-gray-700">Address
          <input className={`${input} mt-1`} value={form.address} onChange={set('address')} required />
        </label>
        <label className="text-sm font-medium text-gray-700">Pincode
          <input className={`${input} mt-1`} value={form.pincode} onChange={set('pincode')} inputMode="numeric" required />
        </label>
        <label className="text-sm font-medium text-gray-700">Phone
          <input className={`${input} mt-1`} value={form.phone} onChange={set('phone')} inputMode="tel" />
        </label>
        <label className="sm:col-span-2 text-sm font-medium text-gray-700">Description (optional)
          <textarea rows={2} className={`${input} mt-1`} value={form.description} onChange={set('description')} />
        </label>
        <label className="text-sm font-medium text-gray-700">Latitude
          <input className={`${input} mt-1`} value={form.latitude} onChange={set('latitude')} inputMode="decimal" required />
        </label>
        <label className="text-sm font-medium text-gray-700">Longitude
          <input className={`${input} mt-1`} value={form.longitude} onChange={set('longitude')} inputMode="decimal" required />
        </label>
      </div>

      <button type="button" onClick={useMyLocation} className="text-sm font-medium text-emerald-700 hover:underline">
        📍 Use my current location
      </button>

      {error && <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{error}</p>}

      <button disabled={busy} className="w-full rounded-lg bg-emerald-600 py-2.5 font-semibold text-white hover:bg-emerald-700 disabled:opacity-60">
        {busy ? 'Submitting…' : 'Submit shop for approval'}
      </button>
    </form>
  );
}
