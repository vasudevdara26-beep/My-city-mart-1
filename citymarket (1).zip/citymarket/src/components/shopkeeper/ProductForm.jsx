import { useState } from 'react';
import { CATEGORIES } from '../../utils/constants';

const UNITS = ['piece', 'pair', 'kg', 'g', 'litre', 'pack', 'dozen'];
const EMPTY = { name: '', category: CATEGORIES[0].id, price: '', mrp: '', stock: '', unit: 'piece', imageUrl: '' };

const input =
  'w-full rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500';

function fromProduct(p) {
  return {
    name: p.name,
    category: p.category || CATEGORIES[0].id,
    price: String(p.price),
    mrp: p.mrp != null ? String(p.mrp) : '',
    stock: String(p.stock_quantity),
    unit: p.unit || 'piece',
    imageUrl: p.image_urls?.[0] || '',
  };
}

/**
 * Add / edit form. Give it `key={editing?.id ?? 'new'}` so it resets when switching modes.
 * `onSubmit(values)` must resolve to true on success.
 */
export default function ProductForm({ initial, onSubmit, onCancel, submitting }) {
  const [values, setValues] = useState(initial ? fromProduct(initial) : EMPTY);
  const [error, setError] = useState('');

  const set = (key) => (e) => setValues((v) => ({ ...v, [key]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    const price = parseFloat(values.price);
    const mrp = values.mrp === '' ? null : parseFloat(values.mrp);
    const stock = parseInt(values.stock, 10);
    const url = values.imageUrl.trim();

    if (!values.name.trim()) return setError('Product name is required.');
    if (Number.isNaN(price) || price < 0) return setError('Enter a valid price.');
    if (mrp !== null && (Number.isNaN(mrp) || mrp < price)) return setError('MRP must be a number at least equal to the price.');
    if (Number.isNaN(stock) || stock < 0) return setError('Stock must be 0 or more.');
    if (url && !/^https?:\/\//i.test(url)) return setError('Image URL must start with http:// or https://');

    // Editing keeps any extra images beyond the first one
    const extraImages = initial?.image_urls?.slice(1) ?? [];
    const ok = await onSubmit({
      name: values.name.trim(),
      category: values.category,
      price,
      mrp,
      stock_quantity: stock,
      unit: values.unit,
      image_urls: url ? [url, ...extraImages] : extraImages,
    });

    if (ok && !initial) setValues(EMPTY);
  }

  const previewOk = /^https?:\/\//i.test(values.imageUrl.trim());

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
      <h2 className="text-lg font-bold text-gray-900">{initial ? `Edit “${initial.name}”` : 'Add a new product'}</h2>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <label className="text-sm font-medium text-gray-700 sm:col-span-2 lg:col-span-2">Product name
          <input className={`${input} mt-1`} value={values.name} onChange={set('name')} placeholder="e.g. Cotton Kurta" required />
        </label>
        <label className="text-sm font-medium text-gray-700">Category
          <select className={`${input} mt-1`} value={values.category} onChange={set('category')}>
            {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
          </select>
        </label>
        <label className="text-sm font-medium text-gray-700">Price (₹)
          <input className={`${input} mt-1`} type="number" min="0" step="0.01" value={values.price} onChange={set('price')} required />
        </label>
        <label className="text-sm font-medium text-gray-700">MRP (₹, optional)
          <input className={`${input} mt-1`} type="number" min="0" step="0.01" value={values.mrp} onChange={set('mrp')} />
        </label>
        <label className="text-sm font-medium text-gray-700">Stock quantity
          <input className={`${input} mt-1`} type="number" min="0" step="1" value={values.stock} onChange={set('stock')} required />
        </label>
        <label className="text-sm font-medium text-gray-700">Unit
          <select className={`${input} mt-1`} value={values.unit} onChange={set('unit')}>
            {UNITS.map((u) => <option key={u}>{u}</option>)}
          </select>
        </label>
        <label className="text-sm font-medium text-gray-700 sm:col-span-2">Image URL
          <div className="mt-1 flex items-center gap-3">
            <input className={input} type="url" value={values.imageUrl} onChange={set('imageUrl')} placeholder="https://…" />
            <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-gray-100 text-gray-300">
              {previewOk ? <img src={values.imageUrl} alt="" className="h-full w-full object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} /> : '🖼️'}
            </div>
          </div>
        </label>
      </div>

      {error && <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{error}</p>}

      <div className="flex gap-2">
        <button disabled={submitting} className="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60">
          {submitting ? 'Saving…' : initial ? 'Save changes' : 'Add product'}
        </button>
        {initial && (
          <button type="button" onClick={onCancel} className="rounded-lg border border-gray-300 px-5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
