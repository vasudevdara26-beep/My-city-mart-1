import { DESTRUCTIVE_STATUSES, NEXT_STATUSES, STATUS_META } from '../../utils/orderStatus';
import { formatCurrency } from '../../utils/formatCurrency';

export default function OrderCard({ order, updating, onStatusChange }) {
  const meta = STATUS_META[order.status] ?? { label: order.status, badge: 'bg-gray-100 text-gray-700' };
  const nextStatuses = NEXT_STATUSES[order.status] ?? [];
  const items = order.order_items ?? [];

  function handleChange(e) {
    const next = e.target.value;
    if (!next) return;
    if (
      DESTRUCTIVE_STATUSES.includes(next) &&
      !window.confirm(`Mark order #${order.order_number} as ${STATUS_META[next].label}? This can't be undone.`)
    ) {
      return;
    }
    onStatusChange(order, next);
  }

  return (
    <article className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="font-bold text-gray-900">Order #{order.order_number}</h3>
          <p className="text-xs text-gray-500">
            {new Date(order.created_at).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
          </p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-semibold ${meta.badge}`}>{meta.label}</span>
      </div>

      {/* Customer */}
      <div className="mt-3 space-y-0.5 rounded-xl bg-gray-50 p-3 text-sm text-gray-700">
        <p className="font-medium text-gray-900">{order.customer_name || 'Customer'}</p>
        {order.customer_phone && (
          <p>📞 <a href={`tel:${order.customer_phone}`} className="text-emerald-700 hover:underline">{order.customer_phone}</a></p>
        )}
        <p>📍 {order.delivery_address}</p>
        {order.notes && <p className="text-amber-700">📝 {order.notes}</p>}
      </div>

      {/* Items */}
      <ul className="mt-3 divide-y divide-gray-100 text-sm">
        {items.map((item) => (
          <li key={item.id} className="flex justify-between gap-3 py-1.5">
            <span className="text-gray-800">{item.product_name} <span className="text-gray-500">× {item.quantity}</span></span>
            <span className="text-gray-700">{formatCurrency(item.line_total)}</span>
          </li>
        ))}
        {items.length === 0 && <li className="py-1.5 text-gray-400">No items found</li>}
      </ul>

      {/* Totals + payment */}
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-gray-100 pt-3 text-sm">
        <span className="text-gray-500">
          {order.payment_method === 'cod' ? 'Cash on delivery' : 'Online payment'} ·{' '}
          <span className={order.payment_status === 'paid' ? 'font-medium text-emerald-700' : 'font-medium text-amber-700'}>
            {order.payment_status}
          </span>
        </span>
        <span className="text-base font-bold text-gray-900">
          {formatCurrency(order.total_amount)}
          {Number(order.delivery_fee) > 0 && (
            <span className="ml-1 text-xs font-normal text-gray-500">(incl. {formatCurrency(order.delivery_fee)} delivery)</span>
          )}
        </span>
      </div>

      {/* Status updater */}
      <div className="mt-3">
        {nextStatuses.length > 0 ? (
          <label className="flex items-center gap-2 text-sm">
            <span className="font-medium text-gray-700">Update status</span>
            <select
              value=""
              onChange={handleChange}
              disabled={updating}
              className="flex-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none focus:border-emerald-500 disabled:opacity-60"
            >
              <option value="">{updating ? 'Updating…' : 'Choose next step…'}</option>
              {nextStatuses.map((s) => (
                <option key={s} value={s}>{STATUS_META[s].label}</option>
              ))}
            </select>
          </label>
        ) : (
          <p className="text-sm text-gray-400">No further actions for this order.</p>
        )}
      </div>
    </article>
  );
}
