import { formatCurrency } from '../../utils/formatCurrency';

const fmtDay = (iso) =>
  new Date(`${iso}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

// Light bar = total sales for the day, dark portion = platform commission
export default function SalesChart({ data }) {
  const max = Math.max(...data.map((d) => Number(d.sales_total)), 1);
  const empty = data.every((d) => Number(d.sales_total) === 0);

  return (
    <div>
      <div className="flex h-44 items-end gap-1" role="img" aria-label="Daily sales chart">
        {data.map((d) => {
          const sales = Number(d.sales_total);
          const comm = Number(d.commission_total);
          return (
            <div key={d.day_date} className="group relative flex h-full flex-1 items-end">
              <div
                className="relative w-full overflow-hidden rounded-t bg-emerald-200"
                style={{ height: `${Math.max((sales / max) * 100, sales > 0 ? 3 : 0)}%` }}
                title={`${fmtDay(d.day_date)}: ${formatCurrency(sales)} sales, ${formatCurrency(comm)} commission, ${d.order_count} orders`}
              >
                <div className="absolute inset-x-0 bottom-0 bg-emerald-600" style={{ height: `${sales ? (comm / sales) * 100 : 0}%` }} />
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-2 flex justify-between text-xs text-gray-500">
        <span>{fmtDay(data[0].day_date)}</span>
        <span>{fmtDay(data[data.length - 1].day_date)}</span>
      </div>

      <div className="mt-3 flex gap-4 text-xs text-gray-600">
        <span className="flex items-center gap-1"><i className="h-2.5 w-2.5 rounded-sm bg-emerald-200" /> Sales</span>
        <span className="flex items-center gap-1"><i className="h-2.5 w-2.5 rounded-sm bg-emerald-600" /> Commission</span>
        {empty && <span className="ml-auto text-gray-400">No delivered orders in this period</span>}
      </div>
    </div>
  );
}
