import { useState } from 'react';
import { updateDefaultCommission } from '../../services/adminService';

const PRESETS = [5, 10, 15];

export default function CommissionSettings({ settings, onSaved }) {
  const [rate, setRate] = useState(String(settings.default_commission_rate));
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ type: '', text: '' });

  const changed = parseFloat(rate) !== Number(settings.default_commission_rate);

  async function save(e) {
    e.preventDefault();
    const value = parseFloat(rate);
    if (Number.isNaN(value) || value < 0 || value > 100) {
      return setMsg({ type: 'error', text: 'Enter a rate between 0 and 100.' });
    }
    setBusy(true);
    setMsg({ type: '', text: '' });
    try {
      const saved = await updateDefaultCommission(value);
      onSaved(saved);
      setMsg({ type: 'ok', text: 'Default commission updated.' });
    } catch (err) {
      setMsg({ type: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={save} className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
      <h2 className="text-lg font-bold text-gray-900">Platform commission</h2>
      <p className="mt-1 text-sm text-gray-500">
        Applied automatically when an order is marked <b>Delivered</b>, on the order subtotal (the shop keeps the delivery fee).
        The rate is locked onto each order at that moment, so changing it never alters past orders.
      </p>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
          Default rate
          <div className="flex items-center rounded-lg border border-gray-300 focus-within:border-emerald-500">
            <input
              type="number" min="0" max="100" step="0.5" value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="w-20 rounded-l-lg px-3 py-2 text-sm outline-none"
            />
            <span className="px-3 text-sm text-gray-500">%</span>
          </div>
        </label>

        <div className="flex gap-1">
          {PRESETS.map((p) => (
            <button type="button" key={p} onClick={() => setRate(String(p))}
              className={`rounded-full px-3 py-1 text-xs font-semibold ${parseFloat(rate) === p ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
              {p}%
            </button>
          ))}
        </div>

        <button disabled={busy || !changed} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50">
          {busy ? 'Saving…' : 'Save'}
        </button>
        {msg.text && <span className={`text-sm ${msg.type === 'ok' ? 'text-emerald-700' : 'text-red-600'}`}>{msg.text}</span>}
      </div>
    </form>
  );
}
