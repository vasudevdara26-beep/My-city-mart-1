import { getCategoryMeta } from '../../utils/constants';

const STATUS_STYLE = {
  pending: 'bg-amber-100 text-amber-800',
  approved: 'bg-emerald-100 text-emerald-800',
  rejected: 'bg-rose-100 text-rose-800',
  suspended: 'bg-gray-200 text-gray-700',
};

export default function ShopReviewCard({ shop, busy, onApprove, onReject, onSuspend }) {
  const category = getCategoryMeta(shop.category);
  const image = shop.banner_url || shop.logo_url;
  const mapUrl = `https://www.google.com/maps?q=${shop.latitude},${shop.longitude}`;

  const primary = 'rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60';
  const danger = 'rounded-lg border border-rose-200 px-4 py-2 text-sm font-semibold text-rose-600 hover:bg-rose-50 disabled:opacity-60';

  return (
    <article className="flex flex-col gap-4 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm sm:flex-row">
      <div className="flex h-28 w-full shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-emerald-100 to-teal-50 text-4xl sm:w-36">
        {image ? <img src={image} alt={shop.name} className="h-full w-full object-cover" /> : <span aria-hidden>{category.icon}</span>}
      </div>

      <div className="min-w-0 flex-1 space-y-1.5">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="truncate text-lg font-bold text-gray-900">{shop.name}</h3>
          <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${STATUS_STYLE[shop.status]}`}>{shop.status}</span>
          <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-700">{category.icon} {category.label}</span>
        </div>

        <p className="text-sm text-gray-600">📍 {shop.address}, {shop.city} {shop.pincode}{' '}
          <a href={mapUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-emerald-700 hover:underline">View on map ↗</a>
        </p>

        <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
          <span>👤 {shop.owner?.full_name || 'Unknown owner'}</span>
          {(shop.phone || shop.owner?.phone) && <span>📞 {shop.phone || shop.owner.phone}</span>}
          <span>🗓 Registered {new Date(shop.created_at).toLocaleDateString('en-IN', { dateStyle: 'medium' })}</span>
        </div>

        {shop.description && <p className="line-clamp-2 text-sm text-gray-600">{shop.description}</p>}
        {shop.rejection_reason && (
          <p className="rounded-lg bg-rose-50 px-3 py-1.5 text-sm text-rose-700">Reason: {shop.rejection_reason}</p>
        )}
      </div>

      <div className="flex shrink-0 flex-row gap-2 sm:flex-col sm:justify-center">
        {shop.status === 'pending' && (
          <>
            <button disabled={busy} onClick={onApprove} className={primary}>Approve</button>
            <button disabled={busy} onClick={onReject} className={danger}>Reject</button>
          </>
        )}
        {shop.status === 'approved' && <button disabled={busy} onClick={onSuspend} className={danger}>Suspend</button>}
        {shop.status === 'suspended' && <button disabled={busy} onClick={onApprove} className={primary}>Reinstate</button>}
        {shop.status === 'rejected' && <button disabled={busy} onClick={onApprove} className={primary}>Approve anyway</button>}
      </div>
    </article>
  );
}
