import { useEffect, useState } from 'react';
import { formatCurrency } from '../../utils/formatCurrency';

const METHODS = ['UPI', 'Bank transfer', 'Cash', 'Other'];
const input = 'mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-emerald-500';

export default function PayoutDialog({ row, onSubmit, onClose }) {
  const balance = Number(row.balance);
  const [direction, setDirection] = useState(balance < 0 ? 'from_shop' : 'to_shop');
  const [amount, setAmount] = useState(Math.abs(balance) > 0 ? Math.abs(balance).toFixed(2) : '');
  const [method, setMethod] = useState(METHODS[0]);
  const [reference, setReference] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  async function submit(e) {
    e.preventDefault();
    const value = parseFloat(amount);
    if (Number.isNaN(value) || value <= 0) return setError('Enter an amount greater than 0.');
    setBusy(true);
    setError('');
    try {
      await onSubmit({
        shop_id: row.shop_id,
        amount: value,
        direction,
        method,
        reference: reference.trim() || null,
        note: note.trim() || null,
      });
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <form role="dialog" aria-modal="true" aria-label="Record settlement" onClick={(e) => e.stopPropagation()} onSubmit={submit}
        className="w-full max-w-md space-y-4 rounded-2xl bg-white p-6 shadow-xl">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Record settlement</h2>
          <p className="text-sm text-gray-500">
            {row.shop_name} · current balance{' '}
            <b className={balance >= 0 ? 'text-emerald-700' : 'text-rose-600'}>
              {balance >= 0 ? `you owe ${formatCurrency(balance)}` : `shop owes ${formatCurrency(-balance)}`}
            </b>
          </p>
        </div>

        <div className="flex gap-2 rounded-lg bg-gray-100 p-1 text-sm font-semibold">
          {[['to_shop', 'I paid the shop'], ['from_shop', 'Shop paid me']].map(([value, label]) => (
            <button type="button" key={value} onClick={() => setDirection(value)}
              className={`flex-1 rounded-md py-1.5 ${direction === value ? 'bg-white shadow-sm' : 'text-gray-500'}`}>
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="text-sm font-medium text-gray-700">Amount (₹)
            <input className={input} type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required />
          </label>
          <label className="text-sm font-medium text-gray-700">Method
            <select className={input} value={method} onChange={(e) => setMethod(e.target.value)}>
              {METHODS.map((m) => <option key={m}>{m}</option>)}
            </select>
          </label>
          <label className="col-span-2 text-sm font-medium text-gray-700">Reference / UTR (optional)
            <input className={input} value={reference} onChange={(e) => setReference(e.target.value)} />
          </label>
          <label className="col-span-2 text-sm font-medium text-gray-700">Note (optional)
            <input className={input} value={note} onChange={(e) => setNote(e.target.value)} />
          </label>
        </div>

        {error && <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{error}</p>}

        <div className="flex justify-end gap-2">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button disabled={busy} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60">
            {busy ? 'Saving…' : 'Save settlement'}
          </button>
        </div>
      </form>
    </div>
  );
}
