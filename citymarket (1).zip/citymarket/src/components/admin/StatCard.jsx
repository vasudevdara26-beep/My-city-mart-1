export default function StatCard({ label, value, hint, icon, tone = 'text-gray-900', loading }) {
  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">{label}</p>
        <span className="text-xl" aria-hidden>{icon}</span>
      </div>
      {loading ? (
        <div className="mt-3 h-8 w-32 animate-pulse rounded bg-gray-200" />
      ) : (
        <p className={`mt-2 text-3xl font-bold ${tone}`}>{value}</p>
      )}
      {hint && !loading && <p className="mt-1 text-xs text-gray-500">{hint}</p>}
    </div>
  );
}
