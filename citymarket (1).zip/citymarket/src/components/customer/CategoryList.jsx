import { CATEGORIES } from '../../utils/constants';

export default function CategoryList({ selected, onSelect }) {
  return (
    <section aria-label="Categories">
      <h2 className="mb-3 text-lg font-bold text-gray-900">Shop by category</h2>
      <div className="flex gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-8 md:overflow-visible">
        {CATEGORIES.map((cat) => {
          const active = selected === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelect(active ? null : cat.id)}
              aria-pressed={active}
              className={`flex min-w-[84px] flex-col items-center gap-1 rounded-2xl border px-3 py-3 text-sm font-medium transition ${
                active
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                  : 'border-gray-200 bg-white text-gray-700 hover:border-emerald-300 hover:bg-emerald-50/50'
              }`}
            >
              <span className="text-3xl" aria-hidden>
                {cat.icon}
              </span>
              {cat.label}
            </button>
          );
        })}
      </div>
    </section>
  );
}
