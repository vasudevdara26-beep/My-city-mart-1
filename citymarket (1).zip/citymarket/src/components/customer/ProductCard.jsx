import { formatCurrency } from '../../utils/formatCurrency';

export default function ProductCard({ product, quantity, onAdd, onIncrease, onDecrease }) {
  const outOfStock = product.stock_quantity <= 0;
  const atLimit = quantity >= product.stock_quantity;
  const hasDiscount = product.mrp && Number(product.mrp) > Number(product.price);
  const discount = hasDiscount
    ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
    : 0;
  const image = product.image_urls?.[0];

  return (
    <article className="flex flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
      <div className="relative aspect-square bg-gray-50">
        {image ? (
          <img src={image} alt={product.name} loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-4xl text-gray-300" aria-hidden>
            🛍️
          </div>
        )}
        {hasDiscount && (
          <span className="absolute left-2 top-2 rounded-full bg-rose-500 px-2 py-0.5 text-xs font-bold text-white">
            {discount}% OFF
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-1 p-3">
        <h3 className="line-clamp-2 text-sm font-semibold text-gray-900">{product.name}</h3>
        <p className="text-xs text-gray-500">per {product.unit}</p>

        <div className="mt-auto flex items-baseline gap-2 pt-1">
          <span className="text-base font-bold text-gray-900">{formatCurrency(product.price)}</span>
          {hasDiscount && (
            <span className="text-xs text-gray-400 line-through">{formatCurrency(product.mrp)}</span>
          )}
        </div>

        <div className="pt-2">
          {outOfStock ? (
            <button disabled className="w-full cursor-not-allowed rounded-lg bg-gray-100 py-2 text-sm font-semibold text-gray-400">
              Out of stock
            </button>
          ) : quantity === 0 ? (
            <button
              onClick={onAdd}
              className="w-full rounded-lg bg-emerald-600 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700 active:scale-95"
            >
              Add to Cart
            </button>
          ) : (
            <div className="flex items-center justify-between rounded-lg bg-emerald-600 text-white">
              <button onClick={onDecrease} aria-label="Decrease quantity" className="px-4 py-2 text-lg font-bold">
                −
              </button>
              <span className="text-sm font-semibold">{quantity}</span>
              <button
                onClick={onIncrease}
                disabled={atLimit}
                aria-label="Increase quantity"
                className="px-4 py-2 text-lg font-bold disabled:opacity-40"
              >
                +
              </button>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}
