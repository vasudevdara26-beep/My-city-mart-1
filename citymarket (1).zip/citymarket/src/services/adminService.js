import { supabase } from '../lib/supabaseClient';

const unwrap = ({ data, error }) => {
  if (error) throw error;
  return data;
};

const SHOP_WITH_OWNER = '*, owner:profiles!owner_id(full_name, phone)';

/* ---------------- Overview ---------------- */

export async function fetchDashboardStats(from = null) {
  return unwrap(await supabase.rpc('admin_dashboard_stats', { p_from: from }));
}

export async function fetchDailySales(days = 14) {
  return unwrap(await supabase.rpc('admin_daily_sales', { p_days: days }));
}

/* ---------------- Shop verification ---------------- */

export async function fetchAllShops() {
  return unwrap(
    await supabase.from('shops').select(SHOP_WITH_OWNER).order('created_at', { ascending: false })
  );
}

export async function fetchPendingShopCount() {
  const { count, error } = await supabase
    .from('shops')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'pending');
  if (error) throw error;
  return count ?? 0;
}

// status: 'approved' | 'rejected' | 'suspended'. `reason` is kept for rejected/suspended only.
export async function setShopStatus(shopId, status, reason = null) {
  return unwrap(
    await supabase
      .from('shops')
      .update({
        status,
        rejection_reason: ['rejected', 'suspended'].includes(status) ? reason : null,
      })
      .eq('id', shopId)
      .select(SHOP_WITH_OWNER)
      .single()
  );
}

/* ---------------- Commission & payouts ---------------- */

export async function fetchCommissionSettings() {
  return unwrap(await supabase.from('platform_settings').select('*').eq('id', 1).single());
}

export async function updateDefaultCommission(rate) {
  return unwrap(
    await supabase
      .from('platform_settings')
      .update({ default_commission_rate: rate, updated_at: new Date().toISOString() })
      .eq('id', 1)
      .select()
      .single()
  );
}

// rate = null removes the override so the shop falls back to the platform default
export async function updateShopCommission(shopId, rate) {
  return unwrap(
    await supabase
      .from('shops')
      .update({ commission_rate: rate })
      .eq('id', shopId)
      .select('id, commission_rate')
      .single()
  );
}

export async function fetchShopBalances() {
  return unwrap(await supabase.rpc('admin_shop_balances'));
}

export async function recordPayout(values) {
  return unwrap(await supabase.from('payouts').insert(values).select('*, shop:shops(name)').single());
}

export async function fetchPayouts(limit = 30) {
  return unwrap(
    await supabase
      .from('payouts')
      .select('*, shop:shops(name)')
      .order('created_at', { ascending: false })
      .limit(limit)
  );
}

/* ---------------- Users ---------------- */

export async function fetchUsers({ role, search } = {}) {
  let q = supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(200);
  if (role) q = q.eq('role', role);
  const term = search?.trim().replace(/[%,()]/g, '');
  if (term) q = q.or(`full_name.ilike.%${term}%,phone.ilike.%${term}%`);
  return unwrap(await q);
}

export async function updateUser(userId, patch) {
  return unwrap(await supabase.from('profiles').update(patch).eq('id', userId).select().single());
}
