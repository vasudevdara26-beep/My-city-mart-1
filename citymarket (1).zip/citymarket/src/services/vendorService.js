import { supabase } from '../lib/supabaseClient';

const slugify = (s) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

/* ---------------- SHOP ---------------- */

export async function fetchMyShop(ownerId) {
  const { data, error } = await supabase
    .from('shops')
    .select('*')
    .eq('owner_id', ownerId)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return data; // null when the shopkeeper hasn't registered a shop yet
}

export async function createShop(ownerId, values) {
  const { data, error } = await supabase
    .from('shops')
    .insert({
      owner_id: ownerId,
      slug: `${slugify(values.name)}-${Math.random().toString(36).slice(2, 6)}`,
      ...values,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateShop(shopId, patch) {
  const { data, error } = await supabase
    .from('shops')
    .update(patch)
    .eq('id', shopId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

/* ---------------- PRODUCTS ---------------- */

export async function fetchShopProducts(shopId) {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('shop_id', shopId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

export async function createProduct(shopId, values) {
  const { data, error } = await supabase
    .from('products')
    .insert({ shop_id: shopId, ...values })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateProduct(productId, patch) {
  const { data, error } = await supabase
    .from('products')
    .update(patch)
    .eq('id', productId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteProduct(productId) {
  const { error } = await supabase.from('products').delete().eq('id', productId);
  if (error) throw error;
}

/* ---------------- ORDERS ---------------- */

export async function fetchShopOrders(shopId) {
  const { data, error } = await supabase
    .from('orders')
    .select('*, order_items(id, product_name, unit_price, quantity, line_total)')
    .eq('shop_id', shopId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

export async function updateOrderStatus(order, status) {
  const patch = { status };
  // Cash on delivery is collected at the door, so delivered = paid
  if (status === 'delivered' && order.payment_method === 'cod') patch.payment_status = 'paid';

  const { data, error } = await supabase
    .from('orders')
    .update(patch)
    .eq('id', order.id)
    .select()
    .single();
  if (error) throw error;
  return data; // row only; caller keeps the nested order_items it already has
}
