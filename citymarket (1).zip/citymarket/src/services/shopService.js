import { supabase } from '../lib/supabaseClient';

const LIST_COLUMNS =
  'id, name, category, logo_url, banner_url, address, city, is_open, delivery_fee, min_order_amount';

export async function fetchShops({ city, category, search } = {}) {
  let query = supabase
    .from('shops')
    .select(LIST_COLUMNS)
    .eq('status', 'approved')
    .order('is_open', { ascending: false })
    .order('name');

  if (city) query = query.eq('city', city);
  if (category) query = query.eq('category', category);
  if (search?.trim()) query = query.ilike('name', `%${search.trim()}%`);

  const { data, error } = await query;
  if (error) throw error;
  return data;
}

export async function fetchShopById(id) {
  const { data, error } = await supabase
    .from('shops')
    .select('*')
    .eq('id', id)
    .eq('status', 'approved')
    .maybeSingle();

  if (error) throw error;
  return data; // null if not found
}
