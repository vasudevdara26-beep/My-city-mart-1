// Keys match the `order_status` enum in the database; labels are what shopkeepers see.
export const STATUS_META = {
  placed: { label: 'Pending', badge: 'bg-amber-100 text-amber-800' },
  accepted: { label: 'Accepted', badge: 'bg-sky-100 text-sky-800' },
  preparing: { label: 'Packing', badge: 'bg-indigo-100 text-indigo-800' },
  out_for_delivery: { label: 'Out for Delivery', badge: 'bg-violet-100 text-violet-800' },
  delivered: { label: 'Delivered', badge: 'bg-emerald-100 text-emerald-800' },
  cancelled: { label: 'Cancelled', badge: 'bg-gray-200 text-gray-700' },
  rejected: { label: 'Rejected', badge: 'bg-rose-100 text-rose-800' },
};

// Which statuses a shopkeeper may move an order to, from each current status.
export const NEXT_STATUSES = {
  placed: ['accepted', 'preparing', 'rejected'],
  accepted: ['preparing', 'out_for_delivery', 'cancelled'],
  preparing: ['out_for_delivery', 'cancelled'],
  out_for_delivery: ['delivered', 'cancelled'],
  delivered: [],
  cancelled: [],
  rejected: [],
};

export const DESTRUCTIVE_STATUSES = ['rejected', 'cancelled'];

export const ORDER_FILTERS = [
  { id: 'all', label: 'All', statuses: null },
  { id: 'new', label: 'New', statuses: ['placed'] },
  { id: 'active', label: 'In progress', statuses: ['accepted', 'preparing', 'out_for_delivery'] },
  { id: 'done', label: 'Delivered', statuses: ['delivered'] },
  { id: 'closed', label: 'Cancelled', statuses: ['cancelled', 'rejected'] },
];
