import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AdminRoute({ children }) {
  const { user, profile, loading, signOut } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-gray-50 text-gray-500">Loading…</div>;
  }

  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;

  if (profile?.role !== 'admin') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
        <div className="max-w-md rounded-2xl border border-gray-200 bg-white p-8 text-center shadow-sm">
          <div className="text-4xl" aria-hidden>🔒</div>
          <h1 className="mt-2 text-lg font-bold text-gray-900">Admins only</h1>
          <p className="mt-1 text-sm text-gray-600">You don't have permission to view this area.</p>
          <button onClick={signOut} className="mt-4 rounded-lg bg-gray-900 px-4 py-2 text-sm font-semibold text-white">
            Sign out
          </button>
        </div>
      </div>
    );
  }

  return children;
}
