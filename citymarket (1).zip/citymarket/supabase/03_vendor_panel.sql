-- Run once in the Supabase SQL Editor.

-- 1. Customer name on orders (shopkeepers can't read other users' profiles under RLS,
--    so checkout should copy the name onto the order).
alter table public.orders add column if not exists customer_name text;

-- 2. Shopkeepers may only change status / payment_status on an order,
--    not amounts, addresses or ownership.
create or replace function public.guard_order_updates()
returns trigger language plpgsql as $$
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if (new.customer_id, new.shop_id, new.subtotal, new.delivery_fee, new.total_amount,
      new.payment_method, new.delivery_address)
     is distinct from
     (old.customer_id, old.shop_id, old.subtotal, old.delivery_fee, old.total_amount,
      old.payment_method, old.delivery_address)
  then
    raise exception 'Only the order status can be changed';
  end if;
  return new;
end; $$;

drop trigger if exists trg_guard_order_updates on public.orders;
create trigger trg_guard_order_updates before update on public.orders
  for each row execute function public.guard_order_updates();

-- 3. Stop shopkeepers approving their own shop (new shops are always 'pending').
create or replace function public.guard_shop_changes()
returns trigger language plpgsql as $$
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if tg_op = 'INSERT' then
    new.status := 'pending';
  elsif new.status is distinct from old.status or new.owner_id is distinct from old.owner_id then
    raise exception 'Only an admin can change shop status or owner';
  end if;
  return new;
end; $$;

drop trigger if exists trg_guard_shop_changes on public.shops;
create trigger trg_guard_shop_changes before insert or update on public.shops
  for each row execute function public.guard_shop_changes();

-- 4. Closes the role-escalation gap flagged in Step 1: users can't promote themselves.
create or replace function public.guard_profile_role()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and not public.is_admin() and new.role is distinct from old.role then
    raise exception 'Only an admin can change roles';
  end if;
  return new;
end; $$;

drop trigger if exists trg_guard_profile_role on public.profiles;
create trigger trg_guard_profile_role before update on public.profiles
  for each row execute function public.guard_profile_role();

-- 5. Realtime: new orders appear live on the dashboard.
--    (If a line errors with "already member of publication", it's already enabled.)
alter publication supabase_realtime add table public.orders;
alter publication supabase_realtime add table public.order_items;

-- 6. Make a test user a shopkeeper (SQL Editor bypasses the role guard):
-- update public.profiles set role = 'shopkeeper' where id = '<AUTH-USER-UUID>';
-- Optionally approve a shop so customers can see it:
-- update public.shops set status = 'approved' where id = '<SHOP-UUID>';
