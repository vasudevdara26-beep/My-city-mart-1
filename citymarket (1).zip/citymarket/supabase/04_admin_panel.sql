-- =====================================================
-- CityMarket: Admin panel migration (safe to re-run)
-- Run AFTER the Step 1 schema and vendor_panel_migration.sql
-- =====================================================

-- ---------- 1. New columns ----------
alter table public.shops
  add column if not exists commission_rate numeric(5,2)
    check (commission_rate is null or (commission_rate >= 0 and commission_rate <= 100)),  -- null = platform default
  add column if not exists rejection_reason text;

alter table public.orders
  add column if not exists commission_rate   numeric(5,2),   -- rate locked in when delivered
  add column if not exists commission_amount numeric(10,2),  -- platform's cut (on subtotal)
  add column if not exists shop_earning      numeric(10,2),  -- total_amount - commission_amount
  add column if not exists delivered_at      timestamptz;

create index if not exists orders_delivered_idx on public.orders (shop_id) where status = 'delivered';

-- ---------- 2. Platform settings (single row) ----------
create table if not exists public.platform_settings (
  id                      int primary key default 1 check (id = 1),
  default_commission_rate numeric(5,2) not null default 10
    check (default_commission_rate >= 0 and default_commission_rate <= 100),
  updated_at              timestamptz not null default now()
);
insert into public.platform_settings (id, default_commission_rate) values (1, 10)
  on conflict (id) do nothing;

alter table public.platform_settings enable row level security;
drop policy if exists "admin reads settings" on public.platform_settings;
drop policy if exists "admin updates settings" on public.platform_settings;
create policy "admin reads settings"   on public.platform_settings for select using (public.is_admin());
create policy "admin updates settings" on public.platform_settings for update
  using (public.is_admin()) with check (public.is_admin());

-- ---------- 3. Payout / settlement ledger ----------
-- to_shop   = admin paid the shopkeeper
-- from_shop = shopkeeper paid the admin (e.g. commission on cash-on-delivery orders)
create table if not exists public.payouts (
  id          uuid primary key default gen_random_uuid(),
  shop_id     uuid not null references public.shops(id) on delete restrict,
  amount      numeric(10,2) not null check (amount > 0),
  direction   text not null check (direction in ('to_shop', 'from_shop')),
  method      text,
  reference   text,
  note        text,
  created_by  uuid references public.profiles(id),
  created_at  timestamptz not null default now()
);
create index if not exists payouts_shop_idx on public.payouts (shop_id);

alter table public.payouts enable row level security;
drop policy if exists "admin manages payouts" on public.payouts;
drop policy if exists "owner reads own payouts" on public.payouts;
create policy "admin manages payouts" on public.payouts for all
  using (public.is_admin()) with check (public.is_admin());
create policy "owner reads own payouts" on public.payouts for select using (
  exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid())
);

-- ---------- 4. Automatic commission when an order is delivered ----------
-- Rate = shop's own rate if set, otherwise the platform default.
-- Commission is charged on the subtotal; the shop keeps the delivery fee.
create or replace function public.set_order_commission()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_rate numeric;
begin
  if new.status = 'delivered' and old.status is distinct from 'delivered' then
    select coalesce(s.commission_rate,
                    (select default_commission_rate from public.platform_settings where id = 1),
                    0)
      into v_rate
      from public.shops s where s.id = new.shop_id;

    new.commission_rate   := v_rate;
    new.commission_amount := round(new.subtotal * v_rate / 100, 2);
    new.shop_earning      := new.total_amount - new.commission_amount;
    new.delivered_at      := now();
    if new.payment_method = 'cod' then new.payment_status := 'paid'; end if;
  end if;
  return new;
end; $$;

-- NOTE: BEFORE triggers fire alphabetically. This name sorts after trg_guard_order_updates,
-- so the guard checks the shopkeeper's edit first and the commission is applied afterwards.
drop trigger if exists trg_set_order_commission on public.orders;
create trigger trg_set_order_commission before update on public.orders
  for each row execute function public.set_order_commission();

-- ---------- 5. Tighter guards (replace the earlier versions) ----------
-- Orders: shopkeepers can't touch money columns, and closed orders can't be reopened
-- (otherwise a shopkeeper could cancel a delivered order to dodge commission).
create or replace function public.guard_order_updates()
returns trigger language plpgsql as $$
begin
  if auth.uid() is null or public.is_admin() then return new; end if;

  if old.status in ('delivered', 'cancelled', 'rejected') and new.status is distinct from old.status then
    raise exception 'This order is closed; its status can no longer be changed';
  end if;

  if (new.customer_id, new.shop_id, new.subtotal, new.delivery_fee, new.total_amount,
      new.payment_method, new.delivery_address,
      new.commission_rate, new.commission_amount, new.shop_earning, new.delivered_at)
     is distinct from
     (old.customer_id, old.shop_id, old.subtotal, old.delivery_fee, old.total_amount,
      old.payment_method, old.delivery_address,
      old.commission_rate, old.commission_amount, old.shop_earning, old.delivered_at)
  then
    raise exception 'Only the order status can be changed';
  end if;
  return new;
end; $$;

-- Shops: only admins may change status, owner, commission rate or rejection reason.
create or replace function public.guard_shop_changes()
returns trigger language plpgsql as $$
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if tg_op = 'INSERT' then
    new.status := 'pending';
    new.commission_rate := null;
    new.rejection_reason := null;
  elsif new.status           is distinct from old.status
     or new.owner_id         is distinct from old.owner_id
     or new.commission_rate  is distinct from old.commission_rate
     or new.rejection_reason is distinct from old.rejection_reason then
    raise exception 'Only an admin can change shop status, owner or commission';
  end if;
  return new;
end; $$;

-- ---------- 6. Admin reporting functions ----------
-- SECURITY DEFINER so they can aggregate across all rows; each one checks is_admin() itself.

create or replace function public.admin_dashboard_stats(p_from timestamptz default null)
returns json language plpgsql security definer set search_path = public stable as $$
declare
  v_sales numeric; v_comm numeric; v_earn numeric; v_orders bigint;
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;

  select coalesce(sum(total_amount), 0), coalesce(sum(commission_amount), 0),
         coalesce(sum(shop_earning), 0), count(*)
    into v_sales, v_comm, v_earn, v_orders
    from public.orders
   where status = 'delivered'
     and (p_from is null or coalesce(delivered_at, created_at) >= p_from);

  return json_build_object(
    'total_sales',       v_sales,
    'total_commission',  v_comm,
    'shop_earnings',     v_earn,
    'delivered_orders',  v_orders,
    'active_shops',      (select count(*) from public.shops    where status = 'approved'),
    'pending_shops',     (select count(*) from public.shops    where status = 'pending'),
    'total_customers',   (select count(*) from public.profiles where role = 'customer'),
    'total_shopkeepers', (select count(*) from public.profiles where role = 'shopkeeper'),
    'open_orders',       (select count(*) from public.orders
                           where status in ('placed', 'accepted', 'preparing', 'out_for_delivery'))
  );
end; $$;

create or replace function public.admin_daily_sales(p_days int default 14)
returns table (day_date date, sales_total numeric, commission_total numeric, order_count bigint)
language plpgsql security definer set search_path = public stable as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  return query
    select d::date,
           coalesce(sum(o.total_amount), 0),
           coalesce(sum(o.commission_amount), 0),
           count(o.id)
      from generate_series(current_date - (p_days - 1), current_date, interval '1 day') d
      left join public.orders o
        on o.status = 'delivered'
       and coalesce(o.delivered_at, o.created_at)::date = d::date
     group by d
     order by d;
end; $$;

-- Per-shop settlement position.
--   Online orders: the platform holds the money  -> platform owes the shop its earning.
--   COD orders:    the shop holds the cash       -> shop owes the platform the commission.
--   balance = online earnings - COD commission - paid to shop + received from shop
--   balance > 0: admin should pay the shop.   balance < 0: shop owes the admin.
create or replace function public.admin_shop_balances()
returns table (
  shop_id uuid, shop_name text, owner_name text, shop_status text,
  effective_rate numeric, custom_rate numeric,
  delivered_orders bigint, gross_sales numeric, commission_total numeric, shop_earnings numeric,
  settled_to_shop numeric, settled_from_shop numeric, balance numeric
)
language plpgsql security definer set search_path = public stable as $$
#variable_conflict use_column
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  return query
    with o as (
      select ord.shop_id as sid,
             count(*)                                   as cnt,
             coalesce(sum(ord.total_amount), 0)         as gross,
             coalesce(sum(ord.commission_amount), 0)    as comm,
             coalesce(sum(ord.shop_earning), 0)         as earn,
             coalesce(sum(ord.shop_earning)      filter (where ord.payment_method = 'online'), 0) as online_earn,
             coalesce(sum(ord.commission_amount) filter (where ord.payment_method = 'cod'), 0)    as cod_comm
        from public.orders ord
       where ord.status = 'delivered'
       group by ord.shop_id
    ), p as (
      select py.shop_id as sid,
             coalesce(sum(py.amount) filter (where py.direction = 'to_shop'), 0)   as paid_to,
             coalesce(sum(py.amount) filter (where py.direction = 'from_shop'), 0) as paid_from
        from public.payouts py
       group by py.shop_id
    )
    select s.id, s.name, pr.full_name, s.status::text,
           coalesce(s.commission_rate, (select default_commission_rate from public.platform_settings where id = 1)),
           s.commission_rate,
           coalesce(o.cnt, 0), coalesce(o.gross, 0), coalesce(o.comm, 0), coalesce(o.earn, 0),
           coalesce(p.paid_to, 0), coalesce(p.paid_from, 0),
           coalesce(o.online_earn, 0) - coalesce(o.cod_comm, 0) - coalesce(p.paid_to, 0) + coalesce(p.paid_from, 0)
      from public.shops s
      left join o  on o.sid = s.id
      left join p  on p.sid = s.id
      left join public.profiles pr on pr.id = s.owner_id
     where s.status in ('approved', 'suspended') or coalesce(o.cnt, 0) > 0
     order by 13 desc, s.name;
end; $$;

revoke all on function public.admin_dashboard_stats(timestamptz) from public, anon;
revoke all on function public.admin_daily_sales(int)             from public, anon;
revoke all on function public.admin_shop_balances()              from public, anon;
grant execute on function public.admin_dashboard_stats(timestamptz) to authenticated;
grant execute on function public.admin_daily_sales(int)             to authenticated;
grant execute on function public.admin_shop_balances()              to authenticated;

-- ---------- 7. Backfill orders that were delivered before this migration ----------
update public.orders o set
  commission_rate   = r.rate,
  commission_amount = round(o.subtotal * r.rate / 100, 2),
  shop_earning      = o.total_amount - round(o.subtotal * r.rate / 100, 2),
  delivered_at      = coalesce(o.delivered_at, o.updated_at)
from (
  select o2.id,
         coalesce(s.commission_rate,
                  (select default_commission_rate from public.platform_settings where id = 1)) as rate
    from public.orders o2 join public.shops s on s.id = o2.shop_id
) r
where r.id = o.id and o.status = 'delivered' and o.commission_amount is null;

-- ---------- 8. Create your first admin (run manually) ----------
-- update public.profiles set role = 'admin' where id = '<AUTH-USER-UUID>';
