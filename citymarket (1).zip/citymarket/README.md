# CityMarket

Hyperlocal multi-vendor marketplace: React (Vite) + Tailwind CSS + Supabase.

## Setup
1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in your Supabase URL and anon key
   (Supabase dashboard -> Project Settings -> API).
3. In the Supabase SQL Editor, run the files in `supabase/` IN ORDER:
   01_schema.sql, 02_customer_panel.sql, 03_vendor_panel.sql, 04_admin_panel.sql
4. `npm run dev`  ->  http://localhost:5173

## Create your first admin
Sign up at /login, then in the SQL Editor:
    update public.profiles set role = 'admin' where id = '<your-user-uuid>';
(Find the uuid in Supabase -> Authentication -> Users.)

## Panels
- Customer:   /            /shop/:id   /cart
- Shopkeeper: /shopkeeper  /shopkeeper/products
- Admin:      /admin       /admin/shops  /admin/commission  /admin/users
